@extends('layouts.auth')

@section('content')

<h1 class="h1 text-white text-center my-5">
    Register is Disabled

</h1>

@endsection
