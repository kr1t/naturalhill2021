<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>

    <?php $setting = App\Models\Setting::find($currentLang->id); ?>
    <!-- Page Title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Meta Data -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="<?php echo $__env->yieldContent('meta'); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <meta name="keywords" content="<?php echo e($setting->keywords); ?>" />
    <meta name="publisher" content="<?php echo e(url()->current()); ?>">
    <meta name="copyright" content="Copyright (c) <?php echo e($setting->title); ?>" />
    <meta name="author" content="<?php echo e($setting->author); ?>" />
    <meta name="contact" content="<?php echo e($setting->contact); ?>" />

    <meta name="revisit-after" content="7 Days" />
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow" />
    <meta name="subjects" content="<?php echo e($setting->title); ?>" />
    <meta name="classification" content="<?php echo e($setting->title); ?>" />

    <meta itemprop="name" content="<?php echo $__env->yieldContent('title'); ?>">
    <meta itemprop="description" content="<?php echo $__env->yieldContent('meta'); ?>">
    <meta itemprop="image" content="<?php echo e(route('home')); ?><?php echo e($setting->photo ? '/images/media/' . $setting->photo->file : '/public/img/200x200.png'); ?>">

    <?php if($setting->OGgraph_switch == 1): ?>

    <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo e(route('home')); ?>" />
    <meta property="og:image" content="<?php echo e(route('home')); ?><?php echo e($setting->photo ? '/images/media/' . $setting->photo->file : '/public/img/200x200.png'); ?>" />
    <meta property="og:site_name" content="<?php echo e($setting->author); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('meta'); ?>" />

    <?php endif; ?>

    <?php if($setting->analytics_switch == 1): ?>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($setting->analytics); ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', '<?php echo e($setting->analytics); ?>');
    </script>

    <?php endif; ?>

    <?php if($setting->facebook_pixel_switch == 1): ?>

    <!-- Facebook Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '<?php echo e($setting->facebook_pixel); ?>');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=<?php echo e($setting->facebook_pixel); ?>&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->

    <?php endif; ?>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e($setting->favicon); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e($setting->favicon); ?>" type="image/x-icon">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">


    <?php if($currentLang->rtl == 1): ?>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e($setting->font); ?>" rel="stylesheet">
    <?php endif; ?>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/front/bootstrap.min.css')); ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo e(asset('css/libs/fontawesome.min.css')); ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo e(asset('css/front/owl.carousel.min.css')); ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo e(asset('css/front/venor.css')); ?>" type="text/css" rel="stylesheet">


    <?php echo $__env->yieldContent('styles'); ?>

    <?php if($currentLang->rtl == 1): ?>
        <link href="<?php echo e(asset('css/front/rtl.css')); ?>" type="text/css" rel="stylesheet">
    <?php endif; ?>


    <!-- Inline Styles -->
    <style>
        body {
            <?php if($currentLang->rtl == 1): ?>
                font-family: 'Cairo', sans-serif;
            <?php else: ?>
                font-family: 'Inter', sans-serif;
            <?php endif; ?>
        }
    </style>

    <?php if($setting->custom_css): ?>
        <style>
            <?php echo $setting->custom_css; ?>

        </style>
    <?php endif; ?>

</head>
<body class="common-front <?php if($currentLang->rtl == 1): ?> rtl <?php endif; ?>" <?php if($currentLang->rtl == 1): ?> dir="rtl" <?php endif; ?>>

    <header class="header">



        <div class="header__content__venor">
            <div class="header__logo">
                <a href="<?php echo e(url('/')); ?>" title="<?php echo e($setting->title); ?>">
                    <img width="210" class="img-fluid logo-front" src="<?php echo e($setting->photo ? '/images/media/' . $setting->photo->file : '/public/img/200x200.png'); ?>" alt="logo">
                </a>
            </div>

            


            <div class="header__menu__venor">


                <ul class="header__nav">

                    <?php $__currentLoopData = $menus->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($prod->on_off_submenu == 1): ?>
                           <li class="header__nav-item dropdown">
                                <a class="header__nav-link dropdown-toggle" href="<?php echo e($prod->link); ?>"  role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e($prod->name); ?>

                                </a>
                                <?php echo $prod->submenu; ?>


                            </li>
                        <?php else: ?>
                             <li class="header__nav-item"> <a title="<?php echo e($prod->name); ?>" class="header__nav-link" href="<?php echo e($prod->link); ?>"><?php echo e($prod->name); ?></a> </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>

            <div class="header__actions__venor">

                

                <div class="header__lang">

                    <?php if(!empty($currentLang) && count($langs) > 1): ?>


                        <a class="header__lang-btn" href="#" role="button" id="dropdownLang" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img width="16" height="16" src="<?php echo e($currentLang->photo ? '/images/media/' . $currentLang->photo->file : '/public/img/200x200.png'); ?>" alt="flag">
                            <span><?php echo e($currentLang->name); ?></span>
                        </a>


                        <ul class="dropdown-menu header__lang-dropdown" aria-labelledby="dropdownLang">
                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a title="<?php echo e($lang->name); ?>"  href='<?php echo e(route('changeLanguage', $lang->code)); ?>'><img width="16" height="16" src="<?php echo e($lang->photo ? '/images/media/' . $lang->photo->file : '/public/img/200x200.png'); ?>" alt="flag"><span><?php echo e($lang->name); ?></span></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>

                </div>

                
            </div>

            <button class="header__btn__venor" type="button">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </header>



    <?php echo $__env->yieldContent('content'); ?>

    <div class="typed-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                        <h4 class="parent-typed-text">
                        <span class="mt_typed-beforetext"><?php echo e($headerfooter->typed_title); ?> </span>
                            <span class="mt_typed_text"></span>

                        </h4>
                </div>
                <div class="col-md-4 text-right">
                    <a href="<?php echo e($headerfooter->typed_buttonlink); ?>" target="_self" class="btn btn-style1"><span><?php echo e($headerfooter->typed_buttontext); ?></span></a>
                </div>
            </div>
        </div>
    </div>


    <footer class="footer-section">
        <div class="footer-wrapper">
            <div class="row align-items-end">
                <div class="col-lg-6">
                    <div class="footer-left">
                        <div class="inner">
                            <span><?php echo e($headerfooter->footer_col1_subtitle); ?></span>
                            <h4><?php echo e($headerfooter->footer_col1_title); ?></h4>
                            <a class="btn btn-style2" href="<?php echo e($headerfooter->footer_col1_buttonlink); ?>" target="_blank"> <span><?php echo e($headerfooter->footer_col1_buttontext); ?></span> </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="footer-right">
                        <div class="row">
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="footer-widget">
                                    <div class="footer-widget widget_nav_menu">
                                        <h4 class="title"><?php echo e($headerfooter->footer_col2_title1); ?></h4>
                                        <span class="venor-animate-border"></span>
                                        <div class="menu-quick-link-container">
                                            <?php echo $headerfooter->footer_col2_html1; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="footer-widget">
                                    <div class="widget widget_custom_html">
                                        <h4 class="title"><?php echo e($headerfooter->footer_col2_title2); ?></h4>
                                        <span class="venor-animate-border"></span>
                                        <div class="custom-html-widget">
                                            <?php echo $headerfooter->footer_col2_html2; ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="copyright-text">
                                    <?php echo $headerfooter->footer_copyright; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"/>
        </svg>
    </div>





    <?php if($setting->SchmeaORG_switch == 1): ?>

    <div class="hidden"  itemscope="" itemtype="https://schema.org/LocalBusiness">
        <span itemprop="description"><?php echo $__env->yieldContent('meta'); ?></span>
        <a itemprop="url" href="<?php echo e(route('home')); ?>"> </a>
        <div itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
        <img src="<?php echo e(route('home')); ?><?php echo e($setting->photo ? '/images/media/' . $setting->photo->file : '/public/img/200x200.png'); ?>" alt="logo" width="120" itemprop="url"></div>
        <span itemprop="name"><?php echo e($setting->title); ?></span>
        <em><span itemprop="priceRange"><?php echo e($setting->price_range); ?></span></em>
        <div itemprop="address" itemscope="" itemtype="https://schema.org/PostalAddress">
            <span itemprop="addressLocality"><?php echo e($setting->address); ?></span> |
            <span itemprop="addressCountry"><?php echo e($setting->country); ?></span> |
            <span itemprop="telephone"><?php echo e($setting->phone); ?></span> |
            <span itemprop="email"><?php echo e($setting->contact); ?></span>
        </div>
    </div>

    <?php endif; ?>


    <?php if($setting->whatsapp == 1): ?>
    
    <?php endif; ?>

    <script src="<?php echo e(asset('js/libs/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/front/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/front/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/front/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/front/simpleParallax.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/front/countTO.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/front/typed.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/front/shuffleLetters.js')); ?> " defer></script>
    <script src="<?php echo e(asset('js/front/tilt.jquery.min.js')); ?> " defer></script>
    <script src="<?php echo e(asset('js/front/magnific.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/front/venor.js')); ?>" defer></script>




    <?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script type="text/javascript">
    ( function ( $ ) {
        'use strict';
        $( document ).ready( function () {
            /* TYPED TEXT */
            $(function(){
                $(".mt_typed_text").typed({
                  strings: <?php echo $headerfooter->typed_text; ?>, //blade / php dynamic functionality
                  typeSpeed: 1,
                  backDelay: 2000,
                  loop: true
                });
            });
        })
    } ( jQuery ) )
    </script>
    <!-- Messenger ปลั๊กอินแชท Code -->
    <div id="fb-root"></div>

    <!-- Your ปลั๊กอินแชท code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "105440655128181");
      chatbox.setAttribute("attribution", "biz_inbox");

      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v11.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>
    <?php if($setting->custom_css): ?>
        <script type="text/javascript">

            <?php echo $setting->custom_js; ?> //blade / php dynamic functionality
        </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('scripts'); ?>



</body>
</html>
<?php /**PATH /Users/arm/Documents/naturalhill2021/resources/views/layouts/front.blade.php ENDPATH**/ ?>