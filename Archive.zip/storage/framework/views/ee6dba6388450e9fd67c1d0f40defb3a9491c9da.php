

<?php $__env->startSection('title'); ?> <?php echo e($project->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($project->meta_description); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/front/magnific.min.css')); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  
   <div class="breadcrumb-area">
       <h1 class="breadcrumb-title"><?php echo e($project->meta_title); ?></h1>
   </div>

   <div class="project-content">
   		<div class="container">
   			<div class="row">
				<div class="col-md-8">
			        <h2 class="post-name"><?php echo e($project->meta_title); ?></h2>
			        <span class="niva-animate-border"></span>
			        <?php echo $project->body; ?>

				</div>
			    <div class="col-md-4">
			        <h4 class="post-name">Info </h4>
			        <span class="niva-animate-border"></span>
			        
			        <p><strong><?php echo e($project->date); ?></strong></p>
			        <p><strong><?php echo e($project->client); ?></strong></p>
			        <p><strong><?php echo e($project->project_category->name); ?></strong></p>

			        <a href="<?php echo e($project->button_link); ?>" target="_blank" class="btn btn-style1"><span><?php echo e($project->button_text); ?></span></a>
			    </div>
			</div>

			<div class="gallery">
				<div class="row">

					<div class="col-md-6">
						<div class="featured-image">
							<a href="<?php echo e($project->img_gal1); ?>">
								<img class="img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal1); ?>">
							</a>
						</div>
					</div>

					<div class="col-md-6">
						<div class="featured-image">
							<a href="<?php echo e($project->img_gal2); ?>">
								<img class="img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal2); ?>">
							</a>
						</div>
					</div>

					<div class="col-md-6">
						<div class="featured-image">
							<a href="<?php echo e($project->img_gal3); ?>">
								<img class="img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal3); ?>">
							</a>
						</div>
					</div>
					
					<div class="col-md-6">
						<div class="featured-image">
							<a href="<?php echo e($project->img_gal4); ?>">
								<img class="img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->img_gal4); ?>">
							</a>
						</div>
					</div>

					<div class="col-md-6">
						<div class="featured-image">
							<a href="<?php echo e($project->photo ? '/public/images/media/' . $project->photo->file : '/public/img/200x200.png'); ?>">
								<img class="img-fluid lazy" src="/public/img/loading-blog.gif" data-src="<?php echo e($project->photo ? '/public/images/media/' . $project->photo->file : '/public/img/200x200.png'); ?>">
							</a>
						</div>
					</div>
				</div>
				
			</div>

   		</div>
   		
   	</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/front/magnific.min.js')); ?>" defer></script>
<script>
( function ( $ ) {
    'use strict';
    $( document ).ready( function () {
        if (jQuery('.gallery').length) {
	      jQuery('.gallery').magnificPopup({
	          delegate: 'a',
	          type: 'image',
	          gallery: {
	              enabled: true
	          },
	          // other options
	      });
	    }
    })
} ( jQuery ) )
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/laravel1.lucian.host/resources/views/project.blade.php ENDPATH**/ ?>