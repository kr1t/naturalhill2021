

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.edit_slider') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.edit_slider') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">

                <a href="<?php echo e(route('slider.index') . '?language=' . request()->input('language')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_slider') , array('Attr.EnableID' => true))); ?> </a>


                <?php if($message = Session::get('slider_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert"><i class="fas fa-times"></i></button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>


                <?php echo $__env->make('includes.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">

                	<div class="col-md-12">

                		<form action="<?php echo e(route('slider.update', $slider->id)); ?>" method="POST" enctype="multipart/form-data">
					        <?php echo csrf_field(); ?>
					        <?php echo method_field('PUT'); ?>

					        <div class="row">

                                <div class="col-xs-12 col-sm-12 col-md-12">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.heading_1') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="heading1" class="form-control" value="<?php echo e($slider->heading1); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.heading_2') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="heading2" class="form-control" value="<?php echo e($slider->heading2); ?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.button_text') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="button_text" class="form-control" value="<?php echo e($slider->button_text); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <strong><?php echo e(clean( trans('niva-backend.button_link') , array('Attr.EnableID' => true))); ?></strong>
                                                <input type="text" name="button_link" class="form-control" value="<?php echo e($slider->button_link); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                       
                                    

                                    <div class="form-group">
                                        <img class="img-fluid pb-4" width="100" height="100" src="<?php echo e($slider->photo ? '/public/images/media/' . $slider->photo->file : '/public/img/200x200.png'); ?>">
                                        <p><strong><?php echo e(clean( trans('niva-backend.photo') , array('Attr.EnableID' => true))); ?></strong></p>
                                        <input type="file"  name="photo_id" class="form-control-file"  id="photo_id">
                                    </div>


                                </div>
					   
	                           
                   

					            <div class="col-xs-12 col-sm-12 col-md-12 text-right">
					                <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
					            </div>
					        </div>

					    </form>
                		
                	</div>
                </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/slider/slider-edit.blade.php ENDPATH**/ ?>