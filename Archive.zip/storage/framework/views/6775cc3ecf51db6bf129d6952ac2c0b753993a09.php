

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e(clean( trans('niva-backend.edit_menu') , array('Attr.EnableID' => true))); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo e(clean( trans('niva-backend.edit_menu') , array('Attr.EnableID' => true))); ?></h6>
        </div>
        <div class="card-body">

                <a href="<?php echo e(route('menu.index') . '?language=' . request()->input('language')); ?>" class="btn btn-primary btn-back"><?php echo e(clean( trans('niva-backend.back_menu') , array('Attr.EnableID' => true))); ?></a>

                <?php if($message = Session::get('menu_success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>    
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>


                <?php echo $__env->make('includes.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">

                	<div class="col-md-12">

                		<form action="<?php echo e(route('menu.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data">
					        <?php echo csrf_field(); ?>
					        <?php echo method_field('PUT'); ?>

					        <div class="row">

                                <div class="col-xs-12 col-sm-12 col-md-12">


                                     <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.name') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($menu->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.link') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="link" class="form-control" placeholder="Link" value="<?php echo e($menu->link); ?>">
                                    </div>

                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.on_off_submenu') , array('Attr.EnableID' => true))); ?></strong>
                                        
                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="on_off_submenu" id="on_off_submenu1" value="1" 
                                            <?php if($menu->on_off_submenu == 1): ?> checked <?php endif; ?>>
                                          <label class="form-check-label" for="on_off_submenu1"> <?php echo e(clean( trans('niva-backend.on') , array('Attr.EnableID' => true))); ?>  </label>
                                        </div>

                                        <div class="form-check">
                                          <input class="form-check-input" type="radio" name="on_off_submenu" id="on_off_submenu0" value="0" 
                                            <?php if($menu->on_off_submenu == 0): ?> checked <?php endif; ?>>
                                          <label class="form-check-label" for="on_off_submenu0"> <?php echo e(clean( trans('niva-backend.off') , array('Attr.EnableID' => true))); ?>  </label>
                                        </div>  
                                        
                                    </div>

                                    <div class="form-group submeniu-code <?php if($menu->on_off_submenu == 0): ?> hide <?php endif; ?>">
                                        <strong><?php echo e(clean( trans('niva-backend.html_submenu') , array('Attr.EnableID' => true))); ?></strong>
                                        <textarea name="submenu" class="form-control" id="submenu" rows="6"><?php echo e(clean( $menu->submenu , array('Attr.EnableID' => true))); ?></textarea>
                                    </div>
                       
                                    <div class="form-group">
                                        <strong><?php echo e(clean( trans('niva-backend.order') , array('Attr.EnableID' => true))); ?></strong>
                                        <input type="text" name="order" class="form-control" value="<?php echo e($menu->order); ?>" placeholder="Order">
                                    </div>


                                </div>
					   
	                           
                   

					            <div class="col-xs-12 col-sm-12 col-md-12 text-right">
					                <button type="submit" class="btn btn-primary"><?php echo e(clean( trans('niva-backend.update') , array('Attr.EnableID' => true))); ?></button>
					            </div>
					        </div>

					    </form>
                		
                	</div>
                </div>

        </div>
    </div>

</div>
<!-- /.container-fluid -->




<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/lucilzud/niva.lucian.host/resources/views/menu/menu-edit.blade.php ENDPATH**/ ?>