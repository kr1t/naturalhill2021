<?php $__env->startSection('title'); ?> <?php echo e($project->meta_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?> <?php echo e($project->meta_description); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(asset('css/front/magnific.min.css')); ?>" type="text/css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="breadcrumb-area">
    <h1 class="breadcrumb-title"><?php echo e($project->meta_title); ?></h1>
</div>

<div class="project-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="post-name"><?php echo e($project->meta_title); ?></h2>
                <span class="venor-animate-border"></span>
            </div>

        </div>

        <div class="gallery">
            <div class="row">

                <?php if(isset($project->img_gal1)): ?>
                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal1); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal1); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal2)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal2); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal2); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal3)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal3); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal3); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal4)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal4); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal4); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal5)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal5); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal5); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal6)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal6); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal6); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal7)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal7); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal7); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>


                <?php if(isset($project->img_gal8)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal8); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal8); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>


                <?php if(isset($project->img_gal9)): ?>

                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal9); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal9); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <?php if(isset($project->img_gal10)): ?>
                <div class="col-md-6">
                    <div class="featured-image">
                        <a href="<?php echo e($project->img_gal10); ?>">
                            <img class="img-fluid lazy" src="/public/img/loading-blog.gif"
                                data-src="<?php echo e($project->img_gal10); ?>">
                        </a>
                    </div>
                </div>
                <?php endif; ?>


            </div>

        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arm/Documents/naturalhill2021/resources/views/gallery-detail.blade.php ENDPATH**/ ?>